# ==========================================================
# GDP Forecasting: ARIMA vs SVR vs Random Forest
# ==========================================================

#This document was originally intended for testing the predictions of three models,
#but was later changed to only display the prediction results of the random forest model.

import numpy as np
import pandas as pd
from sklearn.impute import KNNImputer
import matplotlib.pyplot as plt
import warnings
import os

from statsmodels.tsa.arima.model import ARIMA
from statsmodels.tsa.stattools import adfuller
from sklearn.svm import SVR
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import TimeSeriesSplit

# Set random seeds for reproducibility
np.random.seed(42)

warnings.filterwarnings("ignore")

# ==========================================================
# Plot settings
# ==========================================================
plt.rcParams['font.family'] = 'Arial'
plt.rcParams['axes.unicode_minus'] = False

# ==========================================================
# Output directory
# ==========================================================
output_dir = "/GDP/new"
os.makedirs(output_dir, exist_ok=True)

print("Results will be saved to:")
print(output_dir)

# ==========================================================
# 1 Load Data
# ==========================================================
print("\n" + "="*60)
print("1 DATA LOADING")
print("="*60)

df = pd.read_csv("/GDP/gdp.csv")

# Extract United States GDP
country_data = df[df['COUNTRY'] == 'United States'].iloc[:, 7:].T
country_data.columns = ['GDP']
country_data.index = pd.to_datetime(country_data.index)
country_data['GDP'] = country_data['GDP'].astype(float)

print("\nPreview of data:")
print(country_data.head())

# Train Test Split
train = country_data.iloc[:-5]
test = country_data.iloc[-5:]

print("\nTraining observations:", len(train))
print("Test observations:", len(test))

# ==========================================================
# 2 Stationarity Test (for reference)
# ==========================================================
print("\n" + "="*60)
print("2 ADF TEST")
print("="*60)

def adf_test(series):
    result = adfuller(series)
    print("ADF Statistic:", result[0])
    print("p-value:", result[1])

print("Original series:")
adf_test(train['GDP'])

# Log difference
train_log = np.log(train['GDP'])
train_log_diff = train_log.diff().dropna()
print("\nLog-differenced series:")
adf_test(train_log_diff)

# ==========================================================
# 3 ARIMA Model
# ==========================================================
print("\n" + "="*60)
print("3 ARIMA MODEL")
print("="*60)

best_aic = np.inf
best_order = None

for p in range(3):
    for d in range(2):
        for q in range(3):
            try:
                model = ARIMA(train['GDP'], order=(p,d,q))
                model_fit = model.fit()
                if model_fit.aic < best_aic:
                    best_aic = model_fit.aic
                    best_order = (p,d,q)
            except:
                continue

print("Best ARIMA order:", best_order)
print("Best AIC:", best_aic)

# Rolling forecast
history = [x for x in train['GDP']]
pred_arima = []
for t in range(len(test)):
    model = ARIMA(history, order=best_order)
    model_fit = model.fit()
    forecast = model_fit.forecast()[0]
    pred_arima.append(forecast)
    history.append(test.iloc[t,0])

# ==========================================================
# 4 Machine Learning Data Preparation (Log Difference + Time Trend)
# ==========================================================
print("\n" + "="*60)
print("4 MACHINE LEARNING DATA PREPARATION")
print("="*60)

# Take log and difference for stationarity
train_log = np.log(train['GDP'])
train_log_diff = train_log.diff().dropna()

# Use 5 lags based on ACF (can be adjusted)
lags = 6

imputer = KNNImputer(n_neighbors=2)
# Create lagged features for the log-differenced series
def create_lagged_data(series, lags):
    df = pd.DataFrame()
    for i in range(1, lags+1):
        df[f'lag_{i}'] = series.shift(i)
    df['target'] = series
    df = df.dropna()
    return df

lagged = create_lagged_data(train_log_diff, lags)

# Add time index as extra feature
lagged['time'] = np.arange(len(lagged))

# Features and target
X = lagged.drop(columns=['target'])
y = lagged['target']

# Train-test split (last 5 points of differenced series)
train_size = len(X) - 5
X_train = X.iloc[:train_size]
X_test = X.iloc[train_size:]
y_train = y.iloc[:train_size]
y_test = y.iloc[train_size:]

print(f"X_train shape: {X_train.shape}, y_train shape: {y_train.shape}")
print(f"X_test shape: {X_test.shape}, y_test shape: {y_test.shape}")

# Standardize features (for SVR)
scaler_X = StandardScaler()
X_train_scaled = scaler_X.fit_transform(X_train)
X_test_scaled = scaler_X.transform(X_test)

# Standardize target (helps SVR)
scaler_y = StandardScaler()
y_train_scaled = scaler_y.fit_transform(y_train.values.reshape(-1,1)).ravel()
y_test_scaled = scaler_y.transform(y_test.values.reshape(-1,1)).ravel()

# ==========================================================
# 5 SVR Model (RBF Kernel with Fixed Parameters)
# ==========================================================
print("\n" + "="*60)
print("5 SVR MODEL (RBF Kernel with Fixed Parameters)")
print("="*60)


svr_model = SVR(kernel='rbf', C=300000, gamma=0.0025, epsilon=0.0001)


print("Training SVR with fixed parameters...")
svr_model.fit(X_train_scaled, y_train_scaled)


preds_svr_scaled = svr_model.predict(X_test_scaled)


preds_svr_diff = scaler_y.inverse_transform(preds_svr_scaled.reshape(-1,1)).ravel()


last_log_svr = np.log(train['GDP'].iloc[-1])
pred_svr_gdp = []
for d in preds_svr_diff:
    last_log_svr = last_log_svr + d
    pred_svr_gdp.append(np.exp(last_log_svr))
pred_svr_gdp = np.array(pred_svr_gdp)


rmse_svr = np.sqrt(mean_squared_error(test['GDP'], pred_svr_gdp))
mae_svr = mean_absolute_error(test['GDP'], pred_svr_gdp)
r2_svr = r2_score(test['GDP'], pred_svr_gdp)

print(f"SVR Test RMSE: {rmse_svr:.2f}")
print(f"SVR Test MAE: {mae_svr:.2f}")
print(f"SVR Test R²: {r2_svr:.4f}")


print("\n" + "-"*60)
print("SVR Prediction Results:")
print("-"*60)
print(f"{'Actual':<15} {'Predicted':<15} {'Difference':<15}")
print("-"*60)
for i in range(len(test)):
    actual = test['GDP'].iloc[i]
    predicted = pred_svr_gdp[i]
    diff = actual - predicted
    print(f"{actual:<15.2f} {predicted:<15.2f} {diff:<15.2f}")

print("\n" + "="*60)
print("SVR Model Training Completed")
print("="*60)

# ==========================================================
# 6 Random Forest Model
# ==========================================================
print("\n" + "="*60)
print("6 RANDOM FOREST MODEL")
print("="*60)

rf_params = {
    'n_estimators': 500,
    'max_depth': 6,
    'min_samples_split': 10,
    'min_samples_leaf': 5,
    'random_state': 42
}

print("Training Random Forest...")
rf_model = RandomForestRegressor(**rf_params)
rf_model.fit(X_train, y_train)


pred_rf_diff = rf_model.predict(X_test)


last_log_rf = np.log(train['GDP'].iloc[-1])
pred_rf_gdp = []
for d in pred_rf_diff:
    last_log_rf = last_log_rf + d
    pred_rf_gdp.append(np.exp(last_log_rf))
pred_rf_gdp = np.array(pred_rf_gdp)


rmse_rf = np.sqrt(mean_squared_error(test['GDP'], pred_rf_gdp))
mae_rf = mean_absolute_error(test['GDP'], pred_rf_gdp)
r2_rf = r2_score(test['GDP'], pred_rf_gdp)

print(f"Random Forest Test RMSE: {rmse_rf:.2f}")
print(f"Random Forest Test MAE: {mae_rf:.2f}")
print(f"Random Forest Test R²: {r2_rf:.4f}")


feature_importance = pd.DataFrame({
    'feature': X_train.columns,
    'importance': rf_model.feature_importances_
}).sort_values('importance', ascending=False)
print("\nRandom Forest Feature Importance:")
print(feature_importance)


print("\n" + "-"*60)
print("Random Forest Prediction Results:")
print("-"*60)
print(f"{'Actual':<15} {'Predicted':<15} {'Difference':<15}")
print("-"*60)
for i in range(len(test)):
    actual = test['GDP'].iloc[i]
    predicted = pred_rf_gdp[i]
    diff = actual - predicted
    print(f"{actual:<15.2f} {predicted:<15.2f} {diff:<15.2f}")

# ==========================================================
# 7 Model Evaluation and Comparison
# ==========================================================
print("\n" + "="*60)
print("7 MODEL PERFORMANCE COMPARISON")
print("="*60)

def evaluate_model(true, pred):
    rmse = np.sqrt(mean_squared_error(true, pred))
    mae = mean_absolute_error(true, pred)
    r2 = r2_score(true, pred)
    return rmse, mae, r2

arima_rmse, arima_mae, arima_r2 = evaluate_model(test['GDP'], pred_arima)
svr_rmse, svr_mae, svr_r2 = evaluate_model(test['GDP'], pred_svr_gdp)
rf_rmse, rf_mae, rf_r2 = evaluate_model(test['GDP'], pred_rf_gdp)

comparison_df = pd.DataFrame({
    'Model': ['ARIMA', 'SVR (RBF)', 'Random Forest'],
    'RMSE': [arima_rmse, svr_rmse, rf_rmse],
    'MAE': [arima_mae, svr_mae, rf_mae],
    'R²': [arima_r2, svr_r2, rf_r2]
})

print(comparison_df.to_string(index=False))


best_model_idx = comparison_df['RMSE'].idxmin()
best_model = comparison_df.loc[best_model_idx, 'Model']
print(f"\nBest Model: {best_model} (Lowest RMSE: {comparison_df.loc[best_model_idx, 'RMSE']:.2f})")


comparison_df.to_csv(os.path.join(output_dir, "model_comparison.csv"), index=False)

# ==========================================================
# 8 Forecast Comparison Plot
# ==========================================================
plt.figure(figsize=(12,6))

plt.plot(test.index, test['GDP'], label='Actual', linewidth=3, color='black', marker='o')
# plt.plot(test.index, pred_arima, label='ARIMA', linewidth=2, marker='s')
# plt.plot(test.index, pred_svr_gdp, label='SVR (RBF)', linewidth=2, marker='^')
plt.plot(test.index, pred_rf_gdp, label='Random Forest', linewidth=2, marker='d')

plt.title("GDP Forecast Random Forest")
# plt.title("GDP Forecast Comparison - ARIMA vs SVR vs Random Forest")
plt.xlabel("Year")
plt.ylabel("GDP (USD)")
plt.legend()
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig(os.path.join(output_dir, "forecast_comparison.png"), dpi=300)
plt.show()

# ==========================================================
# 9 Save Detailed Predictions
# ==========================================================
predictions_df = pd.DataFrame({
    'Year': test.index,
    'Actual': test['GDP'].values,
    'ARIMA': pred_arima,
    'SVR_RBF': pred_svr_gdp,
    'Random_Forest': pred_rf_gdp
})

predictions_df.to_csv(os.path.join(output_dir, "predictions_detailed.csv"), index=False)

print("\n" + "="*60)
print("All results saved successfully!")
print(f"Output folder: {output_dir}")
print("="*60)

# ==========================================================
# 10 Summary Statistics
# ==========================================================
print("\n" + "="*60)
print("8 SUMMARY STATISTICS")
print("="*60)

print("\nARIMA Model:")
print(f"  Best Order: {best_order}")
print(f"  AIC: {best_aic:.2f}")

print("\nSVR Model:")
print(f"  Kernel: RBF")
print(f"  C: 300000")
print(f"  Gamma: 0.0025")
print(f"  Epsilon: 0.0001")

print("\nRandom Forest Model:")
print(f"  n_estimators: {rf_params['n_estimators']}")
print(f"  max_depth: {rf_params['max_depth']}")
print(f"  min_samples_split: {rf_params['min_samples_split']}")
print(f"  min_samples_leaf: {rf_params['min_samples_leaf']}")

print("\n" + "="*60)
print("Analysis Complete!")
print("="*60)